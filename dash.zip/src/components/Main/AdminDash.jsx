import React from 'react'

const AdminDash = () => {
  return (
    <div className='flex'>
    <Sidebar/>
    <Dashboard />
  </div>
  )
}

export default AdminDash