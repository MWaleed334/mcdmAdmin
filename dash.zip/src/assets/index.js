import tdllogo from './Images/tdllogo.png';
import billingicon from './Images/billingicon.png';
import companiesicon from './Images/companiesicon.png';
import peoplesicon from './Images/peoplesicon.png';
import trafficdataicon from './Images/trafficdataicon.png';
import settingicon from './Images/settingicon.png';
import pixelicon from './Images/pixelicon.png';
import instructioncrossicon from './Images/instructioncrossicon.png';
import wordPress from './Images/wordPress.png';
import backarrow from "./Images/backarrow.png";
import safari from "./Images/safari.png";
import linkedin from "./Images/linkedin.png";
import searchicon from "./Images/searchicon.png";
import snitcherlogo from "./Images/snitcherlogo.png";
import jobicon from "./Images/jobicon.png";
import  eyeicon from "./Images/eyeicon.png";
import uslogoicon from "./Images/uslogoicon.png";
import danger from "./Images/danger.png";
import authbanner from "./Images/authbanner.png";
export {
  authbanner,
  uslogoicon,
  eyeicon,
  jobicon,
  snitcherlogo,
  searchicon,
  backarrow,
  safari,
  linkedin,
  tdllogo,
  billingicon,
  companiesicon,
  peoplesicon,
  trafficdataicon,
  settingicon,
  pixelicon,
  danger,
  instructioncrossicon,
  wordPress,
};










