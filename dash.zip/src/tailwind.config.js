module.exports = {
    content: [
      './src/**/*.html',
      './src/**/*.js',
    ],
    theme: {
      extend: {},
    },
    plugins: [],
  }
  